<?php
$this_month=date("Y-m");
$today=date("Y-m-d");

?>